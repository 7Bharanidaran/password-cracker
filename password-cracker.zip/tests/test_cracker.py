import hashlib

def test_md5_hash():
    password = "admin"
    expected_hash = hashlib.md5(password.encode()).hexdigest()
    assert expected_hash == "21232f297a57a5a743894a0e4a801fc3"

import hashlib
import sys

def crack_password(hash_to_crack, wordlist_file):
    try:
        with open(wordlist_file, 'r') as file:
            for word in file:
                word = word.strip()
                hashed_word = hashlib.md5(word.encode()).hexdigest()
                if hashed_word == hash_to_crack:
                    print(f"[+] Password found: {word}")
                    return
        print("[-] Password not found in the wordlist.")
    except FileNotFoundError:
        print("[-] Wordlist file not found.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python cracker.py <hash> <wordlist>")
    else:
        crack_password(sys.argv[1], sys.argv[2])

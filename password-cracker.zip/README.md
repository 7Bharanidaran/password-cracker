# Password Cracker

A simple brute-force password cracker written in Python. This tool attempts to crack a password using a list of possible passwords (wordlist).

## Features

- Reads password hashes
- Tries passwords from a wordlist
- Cracks MD5-hashed passwords

## Usage

```bash
python cracker.py <hash> <wordlist>
```

## Example

```bash
python cracker.py 5f4dcc3b5aa765d61d8327deb882cf99 wordlist.txt
```

## Requirements

Install dependencies using:

```bash
pip install -r requirements.txt
```

## Disclaimer

For educational purposes only.
